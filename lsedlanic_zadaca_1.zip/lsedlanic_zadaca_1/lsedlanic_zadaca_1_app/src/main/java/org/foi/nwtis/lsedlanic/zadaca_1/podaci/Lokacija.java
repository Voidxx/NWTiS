package org.foi.nwtis.lsedlanic.zadaca_1.podaci;

public record Lokacija(String naziv, String id, String gpsSirina, String gpsDuzina) {

}
