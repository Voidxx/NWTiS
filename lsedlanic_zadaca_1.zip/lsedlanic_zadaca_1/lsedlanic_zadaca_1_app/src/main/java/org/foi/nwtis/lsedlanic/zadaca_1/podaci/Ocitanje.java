package org.foi.nwtis.lsedlanic.zadaca_1.podaci;

public record Ocitanje(String idUredaja, MeteoSimulacija podaci) {

}
