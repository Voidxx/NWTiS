package org.foi.nwtis.lsedlanic.zadaca_1.podaci;

public record Korisnik(String prezime, String ime, String korisnickoIme, String lozinka, boolean administrator) {

}
