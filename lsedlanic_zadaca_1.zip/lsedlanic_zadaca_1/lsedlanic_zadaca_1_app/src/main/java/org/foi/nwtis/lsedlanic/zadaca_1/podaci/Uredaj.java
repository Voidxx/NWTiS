package org.foi.nwtis.lsedlanic.zadaca_1.podaci;

public record Uredaj(String naziv, String id, String idLokacija, UredajVrsta vrsta) {

}
