package org.foi.nwtis.lsedlanic.zadaca_1.podaci;

public record MeteoSimulacija(String id, String vrijeme, float temperatura, float vlaga, float tlak) {

}
